
import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load and preprocess data
@st.cache_data
def load_data():
    df = pd.read_csv("data/spotify_millsongdata.csv")
    df['text'] = df['text'].fillna('')
    return df

df = load_data()

# TF-IDF
@st.cache_resource
def create_tfidf_matrix(data):
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(data['text'])
    return tfidf_matrix, tfidf

tfidf_matrix, tfidf = create_tfidf_matrix(df)

# Build song lookup
song_indices = pd.Series(df.index, index=df['song'].str.lower()).drop_duplicates()

def get_recommendations(title, top_n=10):
    title = title.lower()
    if title not in song_indices:
        return None

    idx = song_indices[title]
    song_vector = tfidf_matrix[idx]
    cosine_sim = cosine_similarity(song_vector, tfidf_matrix).flatten()

    similar_indices = cosine_sim.argsort()[-top_n-1:-1][::-1]
    return df.iloc[similar_indices][['artist', 'song']].reset_index(drop=True)

def fuzzy_search(query, choices, limit=5):
    return [title for title in choices if query in title][:limit]

# Streamlit UI
st.title("🎵 Music Recommendation System")
song_name = st.text_input("Enter a song title:")

if song_name:
    matched_titles = fuzzy_search(song_name.lower(), song_indices.index)

    if matched_titles:
        selected_title = st.selectbox("Did you mean:", matched_titles)
        if selected_title:
            st.subheader(f"Recommended Songs for: **{selected_title.title()}**")
            recommendations = get_recommendations(selected_title)
            st.dataframe(recommendations)
    else:
        st.warning("No matching songs found. Please try another.")
