# Music Recommendation System

A simple music recommendation system using Streamlit and TF-IDF similarity.

## Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the app:
```
streamlit run app.py
```

## Dataset

The dataset used is a collection of song lyrics and titles.
